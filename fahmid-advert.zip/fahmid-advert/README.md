# Fahmid Nursery & Primary School — Advert Video

A 30-second vertical (1080×1920) advert built with [Remotion](https://www.remotion.dev)
— the video is written as React code, and GitHub Actions renders it to an
MP4 you can download. No video editing software required.

Content and colors are pulled directly from fahmidschool.com.ng (motto,
stats, testimonial, address, contact info, and the school's own navy/gold
palette).

## How to get your video

1. Push this project to a new GitHub repository (see the chat instructions
   for the exact commands).
2. GitHub Actions will automatically render the video. Watch it happen
   under the **Actions** tab of your repo.
3. When the run finishes (green checkmark), open it and download the
   **fahmid-advert-video** artifact — that's your MP4.

## Editing the video yourself later

All the scenes live in `src/Scenes.tsx`, and the order/timing is in
`src/FahmidAdvert.tsx`. Text, colors, and stats can be changed there —
just edit the text between quotes and push; the video re-renders
automatically.
